const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*', // allow all origins
    methods: ['GET', 'POST'],
  },
});

io.on('connection', (socket) => {
  console.log('a user connected');
  console.log('socketId: ', socket);
  socket.on('chat', (msg) => {
    console.log(`${socket.id}: ${msg}`);
    io.emit('chat', `${socket.id}: ${msg}`);
  });
});

server.listen(3000, () => {
  console.log('io server listening on: 3000');
});
