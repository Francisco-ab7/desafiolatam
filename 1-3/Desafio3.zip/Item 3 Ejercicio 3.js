const projects = [
    {"id":1,"name":"Pintar casa","startDay":"2024-01-01","tasks":[{"id":1,"description":"limpiar","status":"Pendiente","deadline":"2024-12-01"},{"id":2,"description":"limpiar otra vez","status":"Pendiente","deadline":"2024-12-25"}]},
    {"id":2,"name":"Cambio de piso","startDay":"2024-02-15","tasks":[{"id":1,"description":"tomar medidas comedor & Living","status":"Pendiente","deadline":"2024-10-22"}]},
    {"id":3,"name":"Arreglar Baño","startDay":"2024-03-20","tasks":[{"id":1,"description":"remover accesorios","status":"Pendiente","deadline":"2024-11-01"},{"id":2,"description":"retirar ceramicass","status":"Pendiente","deadline":"2024-11-01"}]}
  ]

const notifyTaskCompletion = (task) => {
    console.log(`La tarea "${task.description}" del proyecto "${task.projectName}" ha sido completada.`);
};

function createTaskProxy(task, projectName) {
    return new Proxy(task, {
        set(target, prop, value) {
            if (prop === 'status' && value === 'Terminado') {
                target.projectName = projectName; 
                notifyTaskCompletion(target); 
            }
            target[prop] = value; 
            return true;
        }
    });
}
projects.forEach(project => {
    project.tasks = project.tasks.map(task => createTaskProxy(task, project.name));
});
const updateTaskStatus = (projectId, taskId, newStatus) => {
    const project = projects.find(p => p.id === projectId);
    if (!project) {
        console.log("Proyecto no encontrado");
        return;
    }
    const task = project.tasks.find(t => t.id === taskId);
    if (!task) {
        console.log("Tarea no encontrada");
        return;
    }
    task.status = newStatus;
};
updateTaskStatus(1, 1, "Terminado"); 

