const app = require('../../index');
const {Router} = require('express')
const router = Router()
const {getuser,addusers, finduser} = require('../controllers/user.controller')
const jwt = require('jsonwebtoken');

// Middleware de autenticación
const SECRET_KEY = process.env.SECRET_KEY ;
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) {
    console.log('Token no proporcionado');
    return res.sendStatus(401);
  }

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) {
      console.log('Error de verificación de token:', err.message);
      return res.sendStatus(403);
    }
    req.user = user;
    console.log('Token verificado para el usuario:', user.username);
    next();
  });
}



// Ruta para el login
router.post('/login', async (req, res) => {
  const login = await finduser(req, res);
  res.json(login)
});

// Rutas Produccion
router.get('/users', authenticateToken, async (req, res) => {
    const users = await getuser();
    console.log('users =>', users);
    res.json(users);
  });
  
router.post('/users', authenticateToken, async (req, res) => {
    const newUser = await addusers(req, res);
    res.json(newUser);
  });
  module.exports = router