const Users = require("../models/user.model.js");
const jwt = require('jsonwebtoken');
const SECRET_KEY = process.env.SECRET_KEY
require('dotenv').config();



const getuser = async (req, res) => {
  const users = await Users.findAll();
  return users;
};

const addusers = async (req, res) => {
  console.log('=>', req.body);
  const { name, login, password, email } = req.body;
  const newuser = await Users.create({ name, login, password, email });
  return newuser;
};


const finduser = async (req,res) => {
  const { login, password } = req.body;
  const user = await Users.findOne({ 
    where: { login: login, password: password } });
  if (user) {
    const token = jwt.sign({ login }, SECRET_KEY, { expiresIn: '1h' });
    res.json({ token });
  } else {
    res.status(401).send('Credenciales inválidas');
  }
}
module.exports = {getuser,addusers, finduser}