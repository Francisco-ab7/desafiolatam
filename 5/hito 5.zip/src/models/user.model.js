const { DataTypes } = require('sequelize');
const sequelize  = require("../databases/configdb.js");
const Users = sequelize.define("Users", {
 id: {
 type: DataTypes.INTEGER,
 primaryKey: true,
 autoIncrement: true,
 },
 name: {
 type: DataTypes.STRING,
 },
 login: {
 type: DataTypes.STRING,
 },
 password: {
 type: DataTypes.STRING,
 },
 email: {
 type: DataTypes.STRING,
 },
});
module.exports = Users